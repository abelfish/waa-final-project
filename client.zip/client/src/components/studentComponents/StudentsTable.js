import { React, useEffect, useState } from 'react';
import TableRow from './TableRow';
import { useNavigate } from 'react-router-dom';
import Unauthorized from '../403';
import { useDispatch } from 'react-redux';

function StudentsTable() {
  const [students, setStudents] = useState([]);
  const user = JSON.parse(localStorage.getItem('user'));
  console.log(user);
  if(!user.roles.includes('FACULTY')) return <Unauthorized />
  

  function getData() {
    const response = fetch('http://localhost:8080/students/', {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${localStorage.getItem('token')}`,
      },
    })
      .then((response) => {
        return response.json();
      })
      .then((data) => {
        // setStudents(data);
        console.log(data);
      })
      .catch((err) => {
        console.log(err);
        // navigate('/login');
      });
    return response;
  }

  return (
    <div className="mx-6 mt-10">
      <div className="flex flex-col">
        <div className="overflow-x-auto sm:-mx-6 lg:-mx-8">
          <div className="py-2 inline-block min-w-full sm:px-6 lg:px-8">
            <div className="overflow-hidden">
              <table className="min-w-full">
                <thead className="bg-white border-b">
                  <tr>
                    <th
                      scope="col"
                      className="text-sm font-medium text-gray-900 px-6 py-4 text-left"
                    >
                      #
                    </th>
                    <th
                      scope="col"
                      className="text-sm font-medium text-gray-900 px-6 py-4 text-left"
                    >
                      First Name
                    </th>
                    <th
                      scope="col"
                      className="text-sm font-medium text-gray-900 px-6 py-4 text-left"
                    >
                      Last Name
                    </th>
                    <th
                      scope="col"
                      className="text-sm font-medium text-gray-900 px-6 py-4 text-left"
                    >
                      Email
                    </th>
                    <th
                      scope="col"
                      className="text-sm font-medium text-gray-900 px-6 py-4 text-left"
                    >
                      GPA
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {students.map((student, index) => {
                    return <TableRow {...student} key={index} />;
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default StudentsTable;
